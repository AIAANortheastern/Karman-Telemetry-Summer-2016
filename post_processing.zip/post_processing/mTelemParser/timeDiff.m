function [ diffVector ] = timeDiff( times, data )
% time independent differential parser
for i = 1:length(times - 1)
    


end

